﻿namespace Project.Models
{
    public class DeliveryStatusViewModel
    {
        public int OrderId { get; set; }
        public string DeliveryStatus { get; set; }
    }
}
