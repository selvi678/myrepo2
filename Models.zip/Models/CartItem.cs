﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class CartItem
    {
        [Key]
        public int Id { get; set; } // This makes it the primary key

        public int ProductId { get; set; }

        [Required]
        public string ProductName { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public int Quantity { get; set; }

        // Optional: Add navigation property if needed
        // public Product Product { get; set; }
    }
}
